<?php $__env->startSection('content'); ?>
<h1>Admin</h1>

<h2>Seasons</h2>

<?php $__currentLoopData = $seasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h2><?php echo e($season->season); ?></h2>
    <?php if($season->weeks->count() > 0): ?>)
        <ul>
        <?php $__currentLoopData = $season->weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($week->week_num); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <?php echo Form::open(['action' => ['AdminController@create_weeks'], 'method' => 'POST']); ?>

            <?php echo csrf_field(); ?>
            <?php echo e(Form::hidden('season_id', $season->id)); ?>

            <?php echo e(Form::submit('Create weeks?', ['class' => 'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>