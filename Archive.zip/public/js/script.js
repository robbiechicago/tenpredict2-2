$(document).ready(function() {
    console.log('Hi! Thanks for visiting tenPredict.')
})